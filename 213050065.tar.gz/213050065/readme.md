Name : Yasaswini
Roll no: 213050065
Git username : yasaswinid

References :
https://opensource.com/article/19/7/bash-aliases

https://askubuntu.com/questions/234678/how-to-show-ascii-art-at-the-top-of-the-terminal-when-its-opened

https://linuxhint.com/30_bash_script_examples/#t7

